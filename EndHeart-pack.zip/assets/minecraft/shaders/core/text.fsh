#version 330

// Minecraft 26.2's text shader, plus the EndHeart aurora (see endheart:aurora.glsl).
// Text that isn't in the aurora's marker colour is drawn exactly as in vanilla.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

#ifndef IS_GUI
#moj_import <endheart:aurora.glsl>
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

#ifndef IS_GUI
in vec3 auroraRay;
flat in vec4 auroraInfo;
flat in vec4 auroraToward;
#endif

out vec4 fragColor;

void main() {
#ifndef IS_GUI
    if (auroraInfo.w > 0.5) {
        int flags = int(auroraInfo.z + 0.5);
        vec4 aurora = aurora_paint(normalize(auroraRay), auroraToward.xyz, int(auroraInfo.x + 0.5),
                (flags & 2) == 2, (flags & 1) == 1, auroraInfo.y, auroraToward.w, gl_FragCoord.xy);
        if (aurora.a <= 0.0) {
            discard;
        }
        fragColor = aurora;
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
