#version 330

// Minecraft 26.2's text shader, plus the EndHeart aurora (see endheart:aurora.glsl).
// Text that isn't in the aurora's marker colour is drawn exactly as in vanilla.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

#ifndef IS_GUI
#moj_import <endheart:aurora.glsl>
#endif

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

#ifndef IS_GUI
out vec3 auroraRay;
flat out vec4 auroraInfo;
flat out vec4 auroraToward;
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifndef IS_GUI
    auroraRay = vec3(0.0);
    auroraInfo = vec4(0.0);
    auroraToward = vec4(0.0);
    int role;
    int mode;
    bool underground;
    bool fading;
    float width;
    if (aurora_decode(Color, role, mode, underground, fading, width)) {
        if (role != AURORA_ROLE_ANCHOR) {
            // Picture pieces are only for shader mods that replace this shader. Here: all four corners on
            // one point outside the screen, so nothing is drawn.
            gl_Position = vec4(-2.0, -2.0, 0.5, 1.0);
            return;
        }
        // The anchor stands a few blocks from the player toward the bearer.
        // w: how bright the sky behind is (0 = night, 1 = day), from the colour of the fog. The see-through
        // version doesn't get the fog colour; it is used underground and in the Nether, where it's dark anyway.
        auroraToward = vec4(Position.x, 0.0, Position.z, 0.0);
#ifndef IS_SEE_THROUGH
        auroraToward.w = clamp(dot(FogColor.rgb, vec3(0.3, 0.59, 0.11)) * 1.4, 0.0, 1.0);
#endif
        // The anchor becomes a quad over the part of the screen where the aurora can be. A glyph's corners
        // come in this order: top-left, bottom-left, bottom-right, top-right.
        vec4 box = aurora_screen_box(ProjMat, ModelViewMat, auroraToward.xyz, mode, width);
        if (box.x >= box.z || box.y >= box.w) {
            gl_Position = vec4(-2.0, -2.0, 0.5, 1.0);
            return;
        }
        int corner = gl_VertexID % 4;
        vec2 screen = vec2(corner >= 2 ? box.z : box.x, (corner == 0 || corner == 3) ? box.w : box.y);
        vec4 unprojected = inverse(ProjMat) * vec4(screen, 0.5, 1.0);
        vec3 viewRay = unprojected.xyz / unprojected.w;
        auroraRay = inverse(mat3(ModelViewMat)) * viewRay;
        auroraInfo = vec4(float(mode), width, (underground ? 2.0 : 0.0) + (fading ? 1.0 : 0.0), 1.0);
#ifdef IS_SEE_THROUGH
        gl_Position = vec4(screen, 0.5, 1.0);
#else
        // Far away, just inside the render distance: every block closer than that hides it, like the sky.
        float skyDistance = clamp(FogRenderDistanceEnd * AURORA_SKY_DEPTH, 8.0, 4096.0);
        gl_Position = ProjMat * vec4(viewRay * (skyDistance / max(abs(viewRay.z), 0.0001)), 1.0);
#endif
    }
#endif
}
