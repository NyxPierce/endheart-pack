// =====================================================================================================
//  EndHeart aurora: how it is drawn. The look itself (sizes, colours, speeds) is in aurora_look.glsl.
//
//  The plugin shows each player a tiny piece of text in a special "marker" colour. Only that text is
//  changed by this pack: its vertex shader stretches it over the part of the screen where the aurora can
//  be, and its fragment shader paints the aurora there, pixel by pixel, from the direction each pixel looks
//  in. Every other piece of text (name tags, signs, chat) is drawn exactly as in vanilla.
//
//  Marker colour (red, green, blue, 0-255):
//    red   = 228 + underground      underground: 1 = the player can't see the sky (dimmer, see-through)
//    green = 160 + fading * 16 + role * 4 + mode
//                                   fading: 1 = flicker
//                                   role: 0 = the anchor that draws the aurora,
//                                         1-3 = picture pieces, only used when a shader mod (Iris)
//                                               replaces this shader; here they are hidden.
//                                   mode: +1 = faint (all round the sky); +2 is unused. In the Nether
//                                         players only see the aurora on top of the roof, as normal sky.
//    blue  = width                  how wide the aurora is: 0-255 = 0-360 degrees of sky. The plugin
//                                   makes it wider the closer the player is to the bearer.
// =====================================================================================================

#moj_import <minecraft:globals.glsl>
#moj_import <endheart:aurora_look.glsl>

#define AURORA_ROLE_ANCHOR 0
#define AURORA_TAU 6.28318530718
// GameTime counts from 0 to 1 over one Minecraft day (24000 ticks = 1200 seconds), then starts again.
#define AURORA_LOOP_SECONDS 1200.0

/** Reads the marker colour. False for any text that isn't part of the aurora. */
bool aurora_decode(vec4 color, out int role, out int mode, out bool underground, out bool fading,
                   out float width) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    role = 0;
    mode = 0;
    underground = false;
    fading = false;
    width = 0.0;
    if ((c.r & 254) != 228 || (c.g & 224) != 160) {
        return false;
    }
    underground = (c.r & 1) == 1;
    fading = (c.g & 16) == 16;
    role = (c.g >> 2) & 3;
    mode = c.g & 3;
    width = float(c.b) * 360.0 / 255.0;
    return true;
}

/** 0 to 1, going round about once every "seconds", and always a whole number of times per Minecraft day. */
float aurora_phase(float seconds) {
    float cycles = max(1.0, floor(AURORA_LOOP_SECONDS / max(seconds, 0.05) + 0.5));
    return fract(GameTime * cycles);
}

float aurora_hash(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

vec2 aurora_hash2(vec2 p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

/** Smooth random wiggle along x that repeats every "period" cells (so it joins up all round the sky). */
float aurora_noise(float x, float period) {
    float i = floor(x);
    float f = fract(x);
    float a = aurora_hash(mod(i, period));
    float b = aurora_hash(mod(i + 1.0, period));
    return mix(a, b, f * f * (3.0 - 2.0 * f));
}

/** Moves one cell every "seconds", going back to 0 after "period" cells, which looks the same. */
float aurora_drift(float seconds, float period) {
    return aurora_phase(seconds * period) * period;
}

/** The world direction at this many degrees round from "toward" and this many degrees above the horizon. */
vec3 aurora_direction(vec2 toward, float az, float elev) {
    float a = radians(az);
    vec2 side = vec2(-toward.y, toward.x);
    vec2 flat2 = toward * cos(a) + side * sin(a);
    float e = radians(elev);
    return vec3(flat2.x * cos(e), sin(e), flat2.y * cos(e));
}

/**
 * For an aurora all round the sky: the part of the screen between its lowest and highest edge, so the
 * ground below the horizon costs nothing. Minecraft's camera never tilts sideways, so this is a band across
 * the whole width of the screen.
 */
vec4 aurora_screen_band(mat4 proj, mat4 modelView, float bottom, float top) {
    float lowY = 1.0;
    float highY = -1.0;
    bool topBehind = false;
    for (int i = 0; i < 24; i++) {
        float az = float(i) * 15.0;
        vec4 low = proj * vec4(mat3(modelView) * aurora_direction(vec2(1.0, 0.0), az, bottom), 1.0);
        vec4 high = proj * vec4(mat3(modelView) * aurora_direction(vec2(1.0, 0.0), az, top), 1.0);
        if (low.w > 0.001) {
            lowY = min(lowY, low.y / low.w);
        }
        if (high.w > 0.001) {
            highY = max(highY, high.y / high.w);
        } else {
            topBehind = true;
        }
    }
    if (topBehind) {
        highY = 1.0;
    }
    // A little extra, because the edges curve between the points checked.
    return vec4(-1.0, clamp(lowY - 0.05, -1.0, 1.0), 1.0, clamp(highY + 0.05, -1.0, 1.0));
}

/**
 * The part of the screen (-1 to 1) where the aurora can appear, so no work is spent elsewhere. Returns
 * (-1, -1, 1, 1) when that can't be worked out safely (part of it is behind the player), and an empty box
 * (min > max) when it is completely off screen.
 */
vec4 aurora_screen_box(mat4 proj, mat4 modelView, vec3 toward, int mode, float width) {
    bool faint = (mode & 1) == 1;
    float bottom = -AURORA_HORIZON_FADE;
    float top = (faint ? AURORA_FAINT_TOP : AURORA_TOP) + 2.0;
    if (faint || width >= 180.0 || length(toward.xz) < 0.0001) {
        return aurora_screen_band(proj, modelView, bottom, top);
    }
    vec2 t = normalize(toward.xz);
    vec2 lo = vec2(1e9);
    vec2 hi = vec2(-1e9);
    for (int i = 0; i <= 6; i++) {
        float az = (float(i) / 6.0 - 0.5) * width;
        for (int j = 0; j <= 3; j++) {
            float elev = mix(bottom, top, float(j) / 3.0);
            vec4 clip = proj * vec4(mat3(modelView) * aurora_direction(t, az, elev), 1.0);
            if (clip.w <= 0.001) {
                return vec4(-1.0, -1.0, 1.0, 1.0);
            }
            vec2 p = clip.xy / clip.w;
            lo = min(lo, p);
            hi = max(hi, p);
        }
    }
    // A little extra, because the curved edges can bulge out between the points checked.
    vec2 pad = (hi - lo) * 0.08 + 0.05;
    return vec4(clamp(lo - pad, -1.0, 1.0), clamp(hi + pad, -1.0, 1.0));
}

/**
 * The aurora's light seen along dir (a direction in the world, length 1). toward points at the bearer.
 * width: how many degrees of sky it covers (360 = all round). day: 0 at night, 1 under a bright day sky.
 *
 * The look follows Complementary Reimagined's aurora: tall, soft, upright curtains of lavender light, made of
 * several see-through sheets of columns stacked on top of each other, with dark sky between groups of them.
 * The columns keep the same spacing at every width, so a wider aurora just has more of them.
 */
vec4 aurora_paint(vec3 dir, vec3 toward, int mode, bool underground, bool fading, float width, float day,
                  vec2 pixel) {
    bool faint = (mode & 1) == 1;
    float bottom = 0.0;
    float top = faint ? AURORA_FAINT_TOP : AURORA_TOP;
    float elev = degrees(asin(clamp(dir.y, -1.0, 1.0)));
    if (elev < bottom - AURORA_HORIZON_FADE || elev > top + 2.0) {
        return vec4(0.0);
    }
    vec2 flat2 = dir.xz;
    vec2 t = length(toward.xz) > 0.0001 ? normalize(toward.xz) : vec2(1.0, 0.0);
    // Degrees round from the bearer's direction, -180 to 180. The faint version points nowhere.
    float az = faint ? degrees(atan(flat2.y, flat2.x))
            : degrees(atan(t.x * flat2.y - t.y * flat2.x, dot(t, flat2)));
    float halfWidth = faint ? 180.0 : width * 0.5;
    if (abs(az) > halfWidth) {
        return vec4(0.0);
    }

    float span = max(top - bottom, 1.0);
    float h01 = clamp((elev - bottom) / span, 0.0, 1.0);

    // Columns all round the sky: a whole number of them, so the pattern joins up behind the player.
    float ring = faint ? AURORA_FAINT_COLUMNS : floor(360.0 / AURORA_COLUMN_SPACING + 0.5);
    float around = az / 360.0;
    // The curtains ripple slowly sideways, more at the top.
    float ripple = AURORA_SWAY / 10.0 * (0.4 + h01)
            * sin(AURORA_TAU * aurora_phase(AURORA_SWAY_SECONDS) + radians(az) * 3.0);

    float flickerSlot = floor(GameTime * AURORA_LOOP_SECONDS * AURORA_FLICKER_RATE);
    // Waves of light running up the columns.
    float shimmerCells = max(1.0, floor(ring * 0.35 + 0.5));
    float shimmer = 1.0 - AURORA_SHIMMER + AURORA_SHIMMER * aurora_noise(around * shimmerCells
            + h01 * 7.0 - aurora_drift(AURORA_SHIMMER_SECONDS, shimmerCells), shimmerCells);
    // Dark sky between the curtains: a slow, wide pattern switches whole groups of columns on and off.
    float gateCells = max(1.0, floor(ring * 0.42 + 0.5));
    float gate = smoothstep(AURORA_GAPS * 0.75, AURORA_GAPS * 0.75 + 0.3, aurora_noise(around * gateCells
            + 31.0 + aurora_drift(AURORA_DRIFT_SECONDS * 2.5, gateCells), gateCells));
    float light = 0.0;
    float centre = 0.0;
    float twinkle = aurora_phase(AURORA_TWINKLE_SECONDS);
    // The wide-aurora cap: sheets beyond AURORA_WIDE_LAYERS fade out as the aurora widens.
    float extra = 1.0 - smoothstep(AURORA_WIDE_FROM, 360.0, faint ? 360.0 : width);
    float weights = 0.0;
    // In the dark gaps there is nothing to add up, so the columns are skipped (this saves a lot of work).
    if (gate > 0.0) {
        for (int i = 0; i < AURORA_LAYERS; i++) {
            float weight = i < AURORA_WIDE_LAYERS ? 1.0 : extra;
            if (weight <= 0.0) {
                break;
            }
            weights += weight;
            float fi = float(i);
            // Each sheet has columns of a different size, drifts its own way, and starts a little higher.
            float cells = floor(ring * (1.0 + fi * 0.37) + 0.5);
            float drift = aurora_drift(AURORA_DRIFT_SECONDS * ring / cells, cells) * (mod(fi, 2.0) < 1.0 ? 1.0 : -1.0);
            float x = around * cells + ripple + fi * 7.31 + drift;
            float cell = floor(x);
            float start = fi * 0.03;
            // One soft column per cell, at a random spot with a random width, height and brightness. This
            // cell's column and the one in the neighbouring cell on the nearer side are both worked out.
            vec2 id = vec2(cell, cell + (fract(x) < 0.5 ? -1.0 : 1.0));
            vec2 h = aurora_hash2(mod(id, cells) + fi * 13.7);
            vec2 middle = id + 0.5 + (fract(h * 3.17) - 0.5) * 0.7;
            vec2 d = (x - middle) / (AURORA_COLUMN_WIDTH * (0.45 + fract(h * 7.31)));
            // A soft bell shape (close to a Gaussian, but cheaper).
            vec2 bell = max(1.0 - d * d * 0.22, 0.0);
            vec2 column = bell * bell * bell;
            // Each column slowly brightens and fades on its own (a smooth up-and-down wave).
            vec2 wave = abs(fract(twinkle + fract(h * 5.91)) - 0.5) * 2.0;
            vec2 own = 0.3 + 0.7 * wave * wave * (3.0 - 2.0 * wave);
            // Tall columns: they rise softly from near the horizon, are brightest low down, and fade out
            // towards their own (random) top.
            vec2 columnTop = 1.0 - AURORA_HEIGHT_VARIETY * fract(h * 2.71);
            vec2 vertical = smoothstep(start, start + AURORA_FOOT, h01)
                    * (1.0 - smoothstep(columnTop * 0.2, columnTop, vec2(h01)));
            if (fading) {
                own *= mix(vec2(1.0), vec2(0.1), lessThan(aurora_hash2(mod(id, cells) * 0.731 + fi
                        + flickerSlot * 1.37), vec2(AURORA_FLICKER_DROP)));
            }
            vec2 w = column * vertical * own * weight;
            light += w.x + w.y;
            vec2 c2 = column * column;
            centre += dot(c2 * c2 * vertical, own);
        }
    }
    light *= gate * shimmer * 1.6 / max(weights, 1.0);
    centre *= gate * 1.6 / max(weights, 1.0);

    // A faint purple haze behind the curtains, lowest in the sky.
    float haze = AURORA_HAZE * smoothstep(0.0, AURORA_FOOT, h01) * (1.0 - smoothstep(0.0, 0.8, h01));

    // The sides fade out softly. As the aurora closes into a full circle round the player, the fade melts
    // away, so there is no seam behind them. Straight towards the bearer it stays a little brighter, so
    // even all round the sky it still hints at the direction.
    float edges = 1.0;
    if (!faint) {
        float side = 1.0 - smoothstep(halfWidth * 0.55, halfWidth, abs(az));
        edges = mix(side, 1.0, smoothstep(0.8, 1.0, width / 360.0));
        float m = az / AURORA_MIDDLE_WIDTH;
        edges *= 1.0 + AURORA_MIDDLE_GLOW * exp(-m * m);
    }
    float horizon = smoothstep(bottom - AURORA_HORIZON_FADE, bottom + 1.5, elev);

    vec3 tint = mix(AURORA_COLOR_LOW, AURORA_COLOR_MID, smoothstep(0.0, 0.35, h01));
    tint = mix(tint, AURORA_COLOR_HIGH, smoothstep(0.35, 1.0, h01));
    tint = mix(tint, AURORA_CENTRE_COLOR, clamp(centre * AURORA_COLUMN_CORE, 0.0, AURORA_COLUMN_CORE));
    vec3 glow = (tint * light + AURORA_COLOR_MID * haze) * AURORA_BRIGHTNESS;

    float pulse = 1.0 - AURORA_PULSE * (0.5 + 0.5 * sin(AURORA_TAU * aurora_phase(AURORA_PULSE_SECONDS)));
    float whole = 1.0;
    if (fading && aurora_hash(flickerSlot * 0.917 + 0.5) < AURORA_FLICKER_ALL) {
        whole = 0.3;
    }
    float mood = faint ? AURORA_FAINT_BRIGHTNESS : 1.0;
    float strength = underground ? AURORA_UNDERGROUND_BRIGHTNESS : 1.0;
    glow *= edges * horizon * pulse * whole * mood * strength * (1.0 + AURORA_DAY_BOOST * day);

    // Bright parts glow softly instead of clipping. The colour is kept (lavender stays lavender), so
    // overlapping columns never turn into white blobs.
    float peak = max(glow.r, max(glow.g, glow.b));
    glow *= (1.0 - exp(-peak * AURORA_EXPOSURE)) / max(peak, 0.0001);
    // Minecraft blends see-through things over what's behind them; it can't add light. Painting the
    // colour at full strength with "how strong" as its see-through amount comes out as: the aurora's light
    // plus a slightly dimmed background. Over a dark sky that looks like glowing light.
    float alpha = clamp(max(glow.r, max(glow.g, glow.b)), 0.0, 1.0);
    // A tiny per-pixel nudge hides the steps a smooth gradient would show on an 8-bit screen.
    float dither = fract(52.9829189 * fract(dot(pixel, vec2(0.06711056, 0.00583715)))) - 0.5;
    alpha = clamp(alpha + dither / 255.0, 0.0, 1.0);
    if (alpha < 0.004) {
        return vec4(0.0);
    }
    return vec4(clamp(glow / max(alpha, 0.0001), 0.0, 1.0), alpha);
}
