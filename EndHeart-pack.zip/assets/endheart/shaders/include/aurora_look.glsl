// =====================================================================================================
//  EndHeart aurora: THE LOOK
//
//  Every number that decides how the aurora looks for players with the EndHeart resource pack.
//  To change it: edit a number here, run ./make-pack.sh, upload the new zip to the GitHub release,
//  then run /endheart reload on the server. Players get the new look without a new plugin jar.
//
//  The style follows Complementary Reimagined's aurora: tall, soft, upright curtains of lavender light,
//  stacked in see-through sheets, with dark sky between groups of them.
//
//  Angles are in degrees across the sky (0 = horizon, 90 = straight up).
//  Times are in seconds. Colours are red, green, blue from 0.0 to 1.0.
//  Keep the ".0" on decimal numbers: the shader language wants 2.0, not 2.
// =====================================================================================================

// ---- Shape -------------------------------------------------------------------------------------------

// How high the tallest columns reach above the horizon.
#define AURORA_TOP 70.0
// Degrees of sky between neighbouring columns (in each sheet). The aurora's width comes from the plugin
// (config.yml: it widens as players get closer to the bearer); the columns keep this spacing at every
// width, so a wider aurora just has more of them.
#define AURORA_COLUMN_SPACING 8.0
// How wide each column is, compared with the space between columns. 0.15 = thin, 0.5 = wide and soft.
#define AURORA_COLUMN_WIDTH 0.34
// How much dark sky shows between groups of columns: 0 = none, 1 = mostly dark.
#define AURORA_GAPS 0.35
// How many see-through sheets of columns are stacked. Each sheet has a different column size, which
// gives the mix of wide soft columns and thinner bright streaks. More looks richer but costs more on
// weak computers. 2 to 6.
#define AURORA_LAYERS 3
// A cap for when the aurora surrounds a player (close to the bearer, so it fills the whole sky): above
// AURORA_WIDE_FROM degrees wide, the sheets beyond AURORA_WIDE_LAYERS fade out smoothly, and from 360
// degrees on they are skipped, which saves work on weak computers. Set AURORA_WIDE_LAYERS to the same
// number as AURORA_LAYERS for no cap. Measured on a weak laptop GPU (AMD Vega 8, 1280x720), looking away
// from the bearer while the aurora surrounds the player: 1 = about 4.0 ms per frame, 2 = about 4.8 ms,
// 3 (no cap) = about 5.5 ms. The narrow aurora far away costs about 3.5 ms while looking straight at it.
#define AURORA_WIDE_LAYERS 1
#define AURORA_WIDE_FROM 200.0
// How much the columns' heights vary (0 = all the same, 1 = very uneven).
#define AURORA_HEIGHT_VARIETY 0.5
// How softly the columns rise from the horizon: the share of the height over which they fade in.
#define AURORA_FOOT 0.14
// Below the horizon the aurora fades out over this many degrees.
#define AURORA_HORIZON_FADE 3.0

// ---- Colour and brightness ---------------------------------------------------------------------------

// Colour low down, in the middle, and at the top of the columns.
#define AURORA_COLOR_LOW vec3(0.66, 0.40, 1.00)
#define AURORA_COLOR_MID vec3(0.55, 0.32, 1.00)
#define AURORA_COLOR_HIGH vec3(0.32, 0.20, 0.88)
// The pale colour at the centre of the brightest columns.
#define AURORA_CENTRE_COLOR vec3(0.80, 0.66, 1.00)
// How pale the centre of each column gets, 0 to 1.
#define AURORA_COLUMN_CORE 0.2
// Overall brightness of the columns.
#define AURORA_BRIGHTNESS 1.3
// How strongly light builds up. Higher = brighter overall; the brightest parts still never turn flat.
#define AURORA_EXPOSURE 1.6
// A faint purple haze behind the curtains, low in the sky. 0 = none.
#define AURORA_HAZE 0.12
// How much brighter the aurora is straight towards the bearer than at its sides. This shows the
// direction, even when the aurora surrounds a player close to the bearer. 0 = even all the way round.
#define AURORA_MIDDLE_GLOW 0.35
// How wide that brighter middle is, in degrees.
#define AURORA_MIDDLE_WIDTH 30.0
// How bright the aurora is when the player can't see the sky (it then shows through walls), 0 to 1.
#define AURORA_UNDERGROUND_BRIGHTNESS 0.45
// Extra strength under a bright day sky, so it still shows: 1.0 = twice as strong by day.
#define AURORA_DAY_BOOST 1.2

// ---- Motion ------------------------------------------------------------------------------------------

// The curtains ripple slowly sideways, more at the top.
#define AURORA_SWAY 2.5
#define AURORA_SWAY_SECONDS 10.0
// Gentle breathing of the whole aurora: 0.25 = it dims by up to 25%.
#define AURORA_PULSE 0.2
#define AURORA_PULSE_SECONDS 7.0
// Shimmer: waves of light running up the columns. 0 = none, 1 = strong.
#define AURORA_SHIMMER 0.35
#define AURORA_SHIMMER_SECONDS 5.0
// Each column slowly brightens and fades on its own, about this often.
#define AURORA_TWINKLE_SECONDS 12.0
// The columns slowly drift sideways; seconds to move one column's width.
#define AURORA_DRIFT_SECONDS 30.0

// ---- Fading Heart (2 of 3 cracks): flicker -----------------------------------------------------------

// How often per second the flicker changes.
#define AURORA_FLICKER_RATE 6.0
// Share of columns that go dark at any moment (0 to 1).
#define AURORA_FLICKER_DROP 0.25
// Chance that the whole aurora dims for a moment.
#define AURORA_FLICKER_ALL 0.06

// ---- Faint version (bearer on the other side of the End): dim columns all round the sky -------------

#define AURORA_FAINT_BRIGHTNESS 0.35
#define AURORA_FAINT_TOP 45.0
// Columns all the way round the sky.
#define AURORA_FAINT_COLUMNS 36.0

// ---- Sky placement -----------------------------------------------------------------------------------

// Under open sky the aurora is drawn at this share of the player's render distance, so every block
// closer than that (trees, hills, mountains) stands in front of it, like the real sky.
#define AURORA_SKY_DEPTH 0.92
